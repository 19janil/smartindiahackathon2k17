<!DOCTYPE html>
<html lang="en">
<head>
  <title>Home Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   <link rel="stylesheet" href="css/login_form.css">

	
   <style>
 html {
  position: relative;
  min-height: 100%;
}
body {
  /* Margin bottom by footer height */
  margin-bottom: 60px;
  padding-top: 70px;
}
.footer {
  position: absolute;
  bottom: 0;
  width: 100%;
  /* Set the fixed height of the footer here */
  height: 40px;
  background-color: #f5f5f5;
}

</style>
</head>
<body>

<nav class="navbar navbar-fixed-top">
  <div class="container">
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div>
      <ul class="nav navbar-nav navbar-right">
		<li class="col-xs-3"><button onclick="zoomin();">A+</button></li>
		<li class="col-xs-3"><button onclick="normal();">A</button></li>
		<li class="col-xs-3"><button onclick="zoomout();">A-</button></li>
      </ul>
      
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>



<nav class="navbar navbar-default navbar-fixed" style="background:;">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
	  <a href="index.php"><img src="http://disabilityaffairs.gov.in/images/indian-emblem.png" style="height:50px; width:40px"></a>
	  <a href="index.php"><b><span style="font-size:30px;">&nbsp;Divyang</span></b></a>
	  
    </div>
<div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    	  <div class="modal-dialog">
				<div class="loginmodal-container">
					<h1>Login to Your Account</h1><br>
				  <form method="post" action="php/login.php">
					<input type="text" name="user" placeholder="Username">
					<input type="password" name="pass" placeholder="Password">
					<input type="submit" name="login" class="login loginmodal-submit" value="Login">
				  </form>
					
				  <div class="login-help">
					<a href="#">Forgot Password</a>
					<br/><a href="http://www.swavlambancard.gov.in/pwd/application#form_block_1">Get UDID</a>
				  </div>
				</div>
			</div>
		  </div>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content col-sm-6">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h2 class="modal-title">Subscribe</h2>
        </div>
        <div class="modal-body">
         <br>
          <form method="POST">
          <input type="text" name="uname" placeholder="Name" class="form-control" required>
          <br>
          <input type="email" id="email" placeholder="Email" class="form-control" required>
          <br>

          <input type="number" id="UserMobile" maxlength="14" data-fv-numeric="true" data-fv-numeric-message="Please enter valid phone numbers" data-fv-phone-country11="IN" required="required" data-fv-notempty-message="This field cannot be left blank." placeholder="Mobile No. " class="form-control" name="data[User][mobile]" data-fv-field="data[User][mobile]" required>
                  
          <br>
          <label id="myCheck">Disability:</label>
         <div class="checkbox">
         <label><input type="checkbox" name="c1" value="0">General</label>
         </div>
         <div class="checkbox">
         <label><input type="checkbox" name="c1" value="1">Vision</label>
         </div>
         <div class="checkbox">
         <label><input type="checkbox" name="c1" value="2">Deaf</label>
         </div>
         <div class="checkbox">
         <label><input type="checkbox" name="c1" value="3">Physical</label>
         </div>
         <div class="checkbox">
         <label><input type="checkbox" name="c1" value="4">Mental</label>
         </div>
          <input type="submit" class="btn btn-primary" name="subscribe" value="Subscribe" onclick="check();">
          </form>
        </div>
      </div>
    </div>
  </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
		<li style="padding-left:40px;"><a href="#"></a></li>
        <li ><a href="../index.php">Home<span class="sr-only">(current)</span></a></li>
		<li><a href="../complaints.html">Complaints</a></li>
		<li><a href="contact.html">Contact Us</a></li>
		<li><a data-toggle="modal" data-target="#myModal">Subscribe</a></li>
		<li><a data-toggle="modal" data-target="#login-modal">Login</a></li>
      </ul>
      
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="container">
	<ul class="nav nav-pills">
		<li class="active"><a data-toggle="pill" href="#home">Enrolled Schemes</a></li>
		<li><a data-toggle="pill" href="#menu1">Applicable Schemes</a></li>
    </ul>
  
  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
      <h3>Enrolled Schemes</h3>
      <p><?php
	ini_set("allow_url_fopen", 1);
	@session_start();
	$json = file_get_contents('http://localhost:99/api/user/'.$_SESSION['udid']);
	$obj= json_decode($json,true);
	$count=count($obj);
							echo '<div class="">
									<table class="table table-hover">
							  <thead>
								<tr>
								  <th class="col-xs-3 col-md-3">Scheme Name</th>
								  <th class="col-xs-3 col-md-3">Scheme Description</th>
								  <th class="col-xs-3 col-md-3">Application Date</th>
								  <th class="col-xs-3 col-md-3">Status</th>
								</tr>
							  </thead></table></div>';
						for($i=0;$i<$count;$i++){
							echo '<div class="">
									<table class="table table-hover">
								<tbody>
								<tr>
								  <td class="col-xs-3 col-md-3">'.$obj[$i]['SchemeName'].'</td>
								  <td class="col-xs-3 col-md-3">'.$obj[$i]['SchemeDescription'].'</td>
								  <td class="col-xs-3 col-md-3">'.$obj[$i]['ApplicationDate'].'</td>
								  <td class="col-xs-3 col-md-3">'.$obj[$i]['StatusDescription'].'</td>
								</tr>
							  </tbody>
							  </table></div>';}
						
	?></p>

    </div>
    <div id="menu1" class="tab-pane fade">
      <h3>Applicable Schemes</h3>
      <p><?php
		require('db.php');
		//session_start();
		$UDID=$_SESSION['udid'];
		$applicable_schemes=mysqli_query($conn,"select * from usercategory where UDID = '$UDID'");
		echo '<div class="">
									<table class="table table-hover">
							  <thead>
								<tr>
								  <th class="col-xs-4">Scheme Name</th>
								  <th class="col-xs-4">Scheme Description</th>
								</tr>
							  </thead></table></div>';
		while($row= mysqli_fetch_array($applicable_schemes)){
			$disable_category_id=$row['DisabilityCategoryId'];
			$applicable_schemes_inner=mysqli_query($conn,"select * from schemes where DisabilityCategoryId = '$disable_category_id'");
			
			while($row_inner= mysqli_fetch_array($applicable_schemes_inner)){
				echo '<div class="">
							<table class="col-xs-12 table table-hover">
							<tbody>
								<tr>
								  <td class="col-xs-4">'.$row_inner['SchemeName'].'</td>
								  <td class="col-xs-4">'.$row_inner['SchemeDescription'].'</td>
								</tr>
							  </tbody>
							  
							</table>
					 </div>';
			}
		}
		?>
	</p>
    </div>
    
  </div>
</div>

</body>
</html>
